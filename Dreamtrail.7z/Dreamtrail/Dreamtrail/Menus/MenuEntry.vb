﻿Public Class MenuEntry
    Public Enabled As Boolean = True
    Public Text As String = ""

End Class
